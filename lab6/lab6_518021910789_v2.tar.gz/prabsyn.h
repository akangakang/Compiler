/* function prototype from prabsyn.c */

#ifndef PRABSYN_H
#define PRABSYN_H

void pr_exp(FILE *out, A_exp v, int d);

#endif

