Please add -no-pie:
gcc -no-pie -Wl,--wrap,getchar -m64 $TESTCASEDIR/${tfileName}.s runtime.c -o test.out